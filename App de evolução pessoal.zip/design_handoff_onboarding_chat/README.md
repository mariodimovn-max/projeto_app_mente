# Handoff: Onboarding + Chat — App de evolução pessoal (auto-conhecimento)

## Overview
Modelo **único e final** para as duas telas centrais do app: **Onboarding** e **Chat/Sessão**. O produto é um espaço de auto-conhecimento via conversa com uma IA — tom noturno, sereno, íntimo. A IA é uma **presença viva** (aura de luz que respira). NÃO é terapia, NÃO é meditação: é uma *jornada* de auto-descoberta, em que cada conversa é um **mergulho** — quanto mais fundo o usuário desce, mais ele se conhece.

Este modelo consolida as três direções exploradas anteriormente nas partes que o cliente escolheu:
1. **Base "Aura"** — a IA como presença viva, grande e proeminente na coluna esquerda.
2. **Medidor de profundidade** — indicador vertical (Superfície → Correntes → Fundo) que estimula o usuário a se abrir, com feel de jogo: a cada troca a aura *afunda* e o nível sobe.
3. **Alternância voz ⇄ texto** — na mesma interface, troca suave entre escrever e falar.

O modelo cobre **web e mobile**; o mobile espelha o mesmo estado do web.

## About the Design Files
Os arquivos deste pacote são **referências de design em HTML** — um protótipo que mostra aparência e comportamento pretendidos, **não código de produção para copiar direto**. A tarefa é **recriar este design no ambiente do seu app** (o PRD indica React / React Native, Next.js + Supabase), usando os padrões e bibliotecas já estabelecidos ali. `Aura-Modelo.standalone.html` abre offline em qualquer navegador e é **interativo** (alterne voz/texto, clique em enviar para descer a conversa); `Aura - Modelo.dc.html` é o fonte original.

## Fidelity
**High-fidelity (hi-fi).** Cores, tipografia, espaçamentos, raios e animações são finais e devem ser recriados fielmente.

---

## Design Tokens

### Cores
| Uso | Hex |
|---|---|
| Fundo base (mais escuro) | `#070f12` / `#080f12` |
| Fundo petróleo escuro | `#0a161a` / `#0c2027` |
| Fundo petróleo médio (topo da coluna) | `#123640` / `#123840` |
| Superfície de vidro | `rgba(255,255,255,.05)` sobre borda `rgba(255,255,255,.09)` |
| Bolha do usuário | fundo `rgba(255,255,255,.06)`, borda `rgba(255,255,255,.08)` |
| Texto creme (primário) | `#eef4f2` / `#e9f1ee` |
| Texto suave | `rgba(233,241,238,.62)` |
| Texto muted | `rgba(233,241,238,.4–.5)` |
| Acento teal (glow / CTA) | `#7fd0c8` → gradiente CTA `linear-gradient(180deg,#7fd0c8,#4ba39c)` |
| Teal do trilho preenchido | `linear-gradient(180deg,#7fd0c8,#3f8f94)` |
| Teal claro (destaque itálico) | `#a8e0d9` |
| Sálvia (modo voz / mic) | `#9db8a8` · `#8fbdb4` → botão `linear-gradient(180deg,#b9d4c5,#7fb0a2)` |
| Texto sobre CTA teal | `#06201e` |
| Rótulo mono "a aura" | `rgba(168,224,217,.55)` |
| Selo de nível | fundo `rgba(127,208,200,.12)`, borda `rgba(127,208,200,.22)`, texto `#c9f0ea` |

### Tipografia
- **Títulos / voz da IA:** `Newsreader` (serif), pesos 300/400; itálico para ênfase emocional. Onboarding 33–42px; perguntas da aura 17px (mobile) / 20px (web); leitura de profundidade `−Xm` em 40px serif 300.
- **Corpo / UI / bolhas do usuário:** `Instrument Sans`, pesos 400/500/600. Corpo 14–15.5px; botões 15px/600.
- **Rótulos / metadados / medidor:** `Space Mono` 10–11px, `letter-spacing` 0.18–0.3em, MAIÚSCULAS ("SEU ESPAÇO", "PROFUNDIDADE", "A AURA · SUA PRESENÇA", "0m · Superfície").
- Google Fonts: `Newsreader:ital,opsz,wght@0,300;0,400;0,500;1,300;1,400`, `Instrument Sans:400;500;600`, `Space Mono:400`.

### Raio / sombra / espaço
- Moldura de celular: raio `46px` externo, `38px` tela interna. Janela web: raio `18px`.
- Cartões/inputs: raio `16–20px`. Bolha do usuário: `18px` com o canto inferior-direito a `5–6px`.
- Seletor voz/texto (segmented): container raio `14px`, botões `11px`.
- Botão de envio (texto): 56px quadrado arredondado `18px`, gradiente teal. Botão-mic (voz): 56px circular sálvia, com halo `0 0 0 7px rgba(157,184,168,.12)`.
- Sombra de elevação (molduras): `0 42px–46px 74px–80px -28px rgba(0,0,0,.85–.9)`.
- Sombra CTA teal: `0 16px 34px -12px rgba(111,200,193,.6)`.
- Glow da aura (núcleo): `inset 0 0 34px–56px rgba(255,255,255,.26–.28), 0 0 54px–90px rgba(111,200,193,.4–.42)`.

### Animações (sutis)
```css
@keyframes breathe    {0%,100%{transform:scale(1);opacity:.94} 50%{transform:scale(1.06);opacity:1}}   /* núcleo da aura, 7s ease-in-out infinite (6s na mini) */
@keyframes breatheGlow{0%,100%{transform:scale(1);opacity:.55} 50%{transform:scale(1.16);opacity:.85}}  /* glow externo, 7s */
@keyframes wave       {0%,100%{transform:scaleY(.3)} 50%{transform:scaleY(1)}}                          /* waveform, 1.3s; delays .1s escalonados por barra */
@keyframes rise       {0%{opacity:0;transform:translateY(9px)} 100%{opacity:1;transform:translateY(0)}} /* entrada de mensagem, .5s ease */
@keyframes fade       {0%{opacity:0} 100%{opacity:1}}                                                   /* troca de dock voz/texto, .35s */
@keyframes ring       {0%{transform:scale(.9);opacity:.7} 100%{transform:scale(1.5);opacity:0}}         /* anel de escuta no modo voz, 2.4s ease-out infinite */
```
**A aura** = 2 camadas circulares: núcleo `radial-gradient(circle at 40% 36%,#d6f4ef,#6fc8c1 40%,#2a7276 74%,#123e42)` + glow externo desfocado (`blur` 15–24px). Ambas respiram. No **modo voz** ganha um anel pulsante (`ring`).

---

## Layout do Chat (web) — 2 colunas

### Coluna esquerda (270px) — Aura + Medidor de Profundidade
- Fundo em gradiente vertical do petróleo (topo) ao quase-preto (base): `linear-gradient(180deg,#123640 0%,#0c2027 40%,#0a161a 70%,#070f12 100%)`.
- Rótulo "PROFUNDIDADE" no topo (Space Mono).
- **Trilho vertical** (2px, `rgba(127,208,200,.14)`) do topo (~56px) até ~150px do fundo. Uma **barra de preenchimento** teal cresce de cima conforme a profundidade aumenta.
- **Marcadores de nível** ao longo do trilho: `0m · Superfície` (topo), `Correntes` (meio), `Fundo` (base).
- **A aura** (110px) é posicionada sobre o trilho e **desce** conforme a profundidade sobe (transição `top .8s cubic-bezier(.22,1,.36,1)`).
- **Leitura inferior:** `−Xm` grande em serif, selo do nível atual, e uma frase de encorajamento que muda por faixa.

### Coluna direita — Conversa + Dock
- **Fluxo de mensagens** (scroll, auto-scroll ao fim): voz da aura sempre em **serif** com rótulo mono "a aura" acima; usuário sempre em **pílula de vidro** alinhada à direita. Cada mensagem entra com `rise`.
- **Dock inferior:** seletor segmentado **Escrever / Falar** no topo.
  - **Escrever:** campo de vidro placeholder "escreva o que veio agora…" + botão de envio teal (seta ↑).
  - **Falar:** botão-mic sálvia + waveform ao vivo + "ouvindo… fale no seu tempo".
  - Troca entre os dois com fade suave (`.35s`).

### Mobile
Espelha o mesmo estado: cabeçalho com mini-aura + "a aura" e, à direita, `−Xm · Nível`. Uma **mini-barra de profundidade** horizontal fica logo abaixo do cabeçalho (preenchimento teal, mesma transição). Mensagens no mesmo padrão; barra de input única com placeholder "escreva ou toque para falar…" e FAB de microfone teal.

## Mecânica de Profundidade (o "jogo")
- Escala de `0m` a `12m`. **Faixas:** `≤3m` = **Superfície**, `4–7m` = **Correntes**, `≥8m` = **Fundo**.
- A cada troca (usuário responde → aura responde), a profundidade **+2m** (limitada a 12).
- **Frases de encorajamento por faixa:**
  - Superfície → "Você está na superfície. Respire — pode descer no seu tempo."
  - Correntes → "Boas correntes. Aqui os padrões começam a aparecer."
  - Fundo → "Você chegou ao fundo. É aqui que mora o que importa."
- A descida é **visível e recompensadora**: aura afunda, barra cresce, nível/frase mudam. Isso estimula o usuário a se abrir mais.

---

## Onboarding

### Web — 2 colunas
- **Esquerda (420px):** aura **grande** (230px) centralizada sobre fundo radial petróleo, com rótulo "A AURA · SUA PRESENÇA" na base.
- **Direita:** rótulo "SEU ESPAÇO"; título serif "Conheça você **melhor.**" (melhor em itálico teal, 42px); parágrafo introdutório que já apresenta a metáfora do mergulho; CTA teal "Começar a jornada" + botão-fantasma "Como usamos seus dados"; linha de privacidade com bolinha teal ("Privado e criptografado · não é terapia profissional").

### Mobile
Aura 158px centralizada; "SEU ESPAÇO"; "Conheça você **melhor.**" (33px); subtítulo "Cada conversa é um mergulho. Quanto mais fundo, mais você se conhece."; CTA teal fixo na base + linha de privacidade. O bloco central tem `padding-bottom` para não colidir com o CTA.

---

## Interactions & Behavior
- **Onboarding → Chat:** CTA principal inicia a primeira sessão (abertura já visível, 1 toque, sem fricção).
- **Input duplo (voz/texto):** alternável a qualquer momento pelo seletor; sempre presente. No modo voz: estado "ouvindo…" + waveform ao vivo + anel de escuta na aura.
- **Envio:** adiciona mensagem do usuário + resposta da aura (`rise`), aumenta a profundidade, reposiciona a aura e faz auto-scroll ao fim.
- **Estado "pensando":** intensificar `breathe`/glow da aura (presença, não spinner). Opcional: "Pensando sobre o que você trouxe…".
- **Erros (gentis):** "Não consegui entender bem. Pode tentar de novo?" + "Regravar" / "Continuar com texto". Nunca termos técnicos.
- **Crise:** se detectar risco, oferecer contato profissional/emergência.

## State Management
- `mode`: `'texto' | 'voz'`
- `depth`: number (0–12) → deriva `level` (Superfície/Correntes/Fundo), posição da aura, preenchimento do trilho e frase de encorajamento.
- `messages[]`: `{ autor: 'aura' | 'usuario', texto }`
- `sessionState` (sugerido): `'aberta' | 'ouvindo' | 'transcrevendo' | 'pensando'`
- Referência de implementação (no protótipo): incremento de +2m por troca; posição da aura = `52 + (depth/12)*300` px dentro do trilho.

## Assets
- Sem imagens raster. Ícones inline em SVG (microfone, seta ↑, texto/Aa). Aura, waveform, medidor e glow são puramente CSS (gradientes + keyframes) — recrie com os mesmos valores.
- Fontes: Google Fonts (Newsreader, Instrument Sans, Space Mono).
- Nome "seu espaço / a aura" é **placeholder** — substituir pela marca final.

## Files
- `Aura-Modelo.standalone.html` — referência visual **interativa** offline (abra no navegador; alterne voz/texto e envie para ver a profundidade).
- `Aura - Modelo.dc.html` — fonte original do modelo.
